import { Truck, Clock, Shield, MapPin, Wrench, HeartHandshake } from "lucide-react"

export default function ServicesSection() {
  const services = [
    {
      icon: <Truck className="h-10 w-10 text-[#1e40af]" />,
      title: "Guincho para Veículos Leves",
      description:
        "Atendimento rápido para carros de passeio, com equipamentos modernos que garantem a segurança do seu veículo.",
    },
    {
      icon: <Clock className="h-10 w-10 text-[#1e40af]" />,
      title: "Atendimento 24 Horas",
      description:
        "Estamos disponíveis dia e noite, incluindo finais de semana e feriados, para atender suas emergências.",
    },
    {
      icon: <Shield className="h-10 w-10 text-[#1e40af]" />,
      title: "Guincho para Veículos Pesados",
      description:
        "Equipamentos especializados para caminhões, ônibus e máquinas pesadas, com equipe treinada para operações complexas.",
    },
    {
      icon: <MapPin className="h-10 w-10 text-[#1e40af]" />,
      title: "Cobertura Ampla",
      description:
        "Atendemos em toda região metropolitana e principais rodovias, garantindo suporte onde você estiver.",
    },
    {
      icon: <Wrench className="h-10 w-10 text-[#1e40af]" />,
      title: "Assistência Mecânica",
      description:
        "Além do guincho, oferecemos serviços básicos de mecânica para tentar resolver seu problema no local.",
    },
    {
      icon: <HeartHandshake className="h-10 w-10 text-[#1e40af]" />,
      title: "Atendimento Personalizado",
      description:
        "Entendemos que cada situação é única. Nossa equipe está preparada para oferecer soluções personalizadas para seu problema.",
    },
  ]

  return (
    <section id="servicos" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-black">Nossos Serviços</h2>
          <p className="text-lg text-black/70 mt-2">
            Soluções completas para todas as suas necessidades de guincho e reboque
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-md border border-gray-100 hover:shadow-lg transition-shadow"
            >
              <div className="flex flex-col h-full">
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-black/70 flex-grow">{service.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center bg-[#1e40af]/10 p-6 rounded-lg">
          <h3 className="text-xl font-bold text-[#1e40af] mb-3">Não encontrou o serviço que precisa?</h3>
          <p className="text-black/80 mb-4">
            Entre em contato conosco! Temos soluções personalizadas para atender suas necessidades específicas.
          </p>
          <a
            href="tel:+5511996034000"
            className="inline-flex items-center justify-center gap-2 rounded-md bg-[#1e40af] px-6 py-3 text-white font-medium hover:bg-[#1e40af]/90 transition-colors"
          >
            <Phone className="h-5 w-5" />
            Ligar Agora (11) 99603-4000
          </a>
        </div>
      </div>
    </section>
  )
}

import { Phone } from "lucide-react"
