import { CreditCard, Banknote, QrCode, Receipt } from "lucide-react"

export default function PaymentMethods() {
  const methods = [
    {
      icon: <QrCode className="h-10 w-10 text-[#1e40af]" />,
      title: "PIX",
      description: "Transferência instantânea, disponível 24 horas por dia. Pagamento confirmado na hora.",
    },
    {
      icon: <CreditCard className="h-10 w-10 text-[#1e40af]" />,
      title: "Cartão de Crédito",
      description: "Aceitamos todas as principais bandeiras. Parcele em até 12x (consulte condições).",
    },
    {
      icon: <Banknote className="h-10 w-10 text-[#1e40af]" />,
      title: "Cartão de Débito",
      description: "Pagamento direto da sua conta bancária, prático e seguro.",
    },
    {
      icon: <Receipt className="h-10 w-10 text-[#1e40af]" />,
      title: "Boleto Bancário",
      description: "Opção para quem prefere pagar posteriormente. Compensação em até 3 dias úteis.",
    },
  ]

  return (
    <section id="pagamento" className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-black">Meios de Pagamento</h2>
          <p className="text-lg text-black/70 mt-2">
            Facilitamos seu pagamento com diversas opções para sua comodidade
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {methods.map((method, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-md border border-gray-100 hover:shadow-lg transition-shadow"
            >
              <div className="flex flex-col items-center text-center">
                <div className="mb-4 p-3 bg-gray-50 rounded-full">{method.icon}</div>
                <h3 className="text-xl font-bold mb-2">{method.title}</h3>
                <p className="text-black/70">{method.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-lg font-medium">
            Não se preocupe com o pagamento agora. <span className="text-[#1e40af]">Sua segurança vem primeiro!</span>
          </p>
          <p className="mt-2 text-black/70">
            Solicite nosso guincho e resolva a forma de pagamento após o atendimento.
          </p>
        </div>
      </div>
    </section>
  )
}
