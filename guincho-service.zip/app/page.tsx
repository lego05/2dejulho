import Link from "next/link"
import Image from "next/image"
import { Phone, MessageCircle } from "lucide-react"
import ContactForm from "@/components/contact-form"
import PaymentMethods from "@/components/payment-methods"
import TestimonialCarousel from "@/components/testimonial-carousel"
import ServicesSection from "@/components/services-section"
import WhatsAppButton from "@/components/whatsapp-button"
import Header from "@/components/header"

export default function Home() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        {/* Floating WhatsApp Button */}
        <WhatsAppButton />

        {/* Section 1: Home */}
        <section id="home" className="bg-gray-100 py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-5xl font-bold text-black leading-tight">
                  Serviço de Guincho 24 Horas
                  <span className="block text-[#1e40af] mt-2 text-2xl md:text-3xl">Serviço de Guincho 25 Horas</span>
                </h1>
                <p className="text-lg text-black/80">
                  Não fique desamparado na estrada. Nossa equipe está pronta para atender sua emergência a qualquer hora
                  do dia ou da noite, garantindo segurança e tranquilidade para você e seu veículo.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Link
                    href="tel:+5511996034000"
                    className="inline-flex items-center justify-center gap-2 rounded-md bg-[#1e40af] px-6 py-3 text-white font-medium hover:bg-[#1e40af]/90 transition-colors"
                  >
                    <Phone className="h-5 w-5" />
                    Ligar Emergência
                  </Link>
                  <Link
                    href="https://wa.me/5511996034000?text=Olá.%20Gostária%20de%20solicitar%20um%20guincho"
                    target="_blank"
                    className="inline-flex items-center justify-center gap-2 rounded-md border border-[#1e40af] px-6 py-3 text-[#1e40af] font-medium hover:bg-[#1e40af]/10 transition-colors"
                  >
                    <MessageCircle className="h-5 w-5" />
                    WhatsApp 24 horas
                  </Link>
                </div>
              </div>
              <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="/images/guincho-truck.jpg"
                  alt="Guincho da empresa 2 de Julho - Volkswagen Delivery branco"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </section>

        {/* Section 2: Our Services */}
        <ServicesSection />

        {/* Section 3: Contact */}
        <section id="contato" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-black">Entre em Contato</h2>
              <p className="text-lg text-black/70 mt-2">
                Estamos prontos para atender sua solicitação. Preencha o formulário abaixo.
              </p>
            </div>
            <ContactForm />
          </div>
        </section>

        {/* Section 4: Payment Methods */}
        <PaymentMethods />

        {/* Section 5: Testimonials */}
        <section id="depoimentos" className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-black">O Que Nossos Clientes Dizem</h2>
              <p className="text-lg text-black/70 mt-2">A satisfação dos nossos clientes é nossa maior recompensa</p>
            </div>
            <TestimonialCarousel />
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-[#1e40af] text-white py-8">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">2 de Julho</h3>
                <p>Serviços de guincho 24 horas para todo tipo de veículo.</p>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Contato</h3>
                <p>Telefone: (11) 99603-4000</p>
                <p>WhatsApp: (11) 99603-4000</p>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Horário</h3>
                <p>Atendimento 24 horas, 7 dias por semana</p>
                <p>Incluindo feriados</p>
              </div>
            </div>
            <div className="border-t border-white/20 mt-8 pt-8 text-center">
              <p>© {new Date().getFullYear()} 2 de Julho - Todos os direitos reservados</p>
            </div>
          </div>
        </footer>
      </main>
    </>
  )
}
