"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Testimonial {
  name: string
  location: string
  text: string
  rating: number
}

export default function TestimonialCarousel() {
  const testimonials: Testimonial[] = [
    {
      name: "Carlos Silva",
      location: "São Paulo, SP",
      text: "Meu carro quebrou na estrada às 2h da manhã. Liguei para o guincho 2 de Julho e em menos de 30 minutos eles estavam lá. Serviço rápido, profissional e me salvou de uma situação muito complicada!",
      rating: 5,
    },
    {
      name: "Mariana Costa",
      location: "Guarulhos, SP",
      text: "Já precisei dos serviços do guincho 2 de Julho duas vezes e nas duas fui muito bem atendida. Equipe educada, preço justo e chegaram no tempo prometido. Recomendo a todos!",
      rating: 5,
    },
    {
      name: "Roberto Almeida",
      location: "Osasco, SP",
      text: "Tive um problema com meu caminhão e precisava de um guincho especializado. A equipe do 2 de Julho foi extremamente profissional e cuidadosa com meu veículo. Serviço de primeira qualidade!",
      rating: 5,
    },
    {
      name: "Fernanda Lima",
      location: "Santo André, SP",
      text: "Meu carro parou na rodovia e eu estava com meus filhos. Fiquei desesperada, mas o atendimento do guincho 2 de Julho foi rápido e me tranquilizou. Chegaram em 20 minutos e resolveram tudo!",
      rating: 5,
    },
    {
      name: "Paulo Mendes",
      location: "São Bernardo, SP",
      text: "Serviço excelente! Atendimento 24 horas realmente funciona. Precisei às 4h da madrugada e fui prontamente atendido. Preço justo e equipe muito preparada. Recomendo!",
      rating: 5,
    },
  ]

  const [currentIndex, setCurrentIndex] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (autoplay) {
      interval = setInterval(() => {
        setCurrentIndex((prevIndex) => (prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1))
      }, 5000)
    }

    return () => clearInterval(interval)
  }, [autoplay, testimonials.length])

  const handlePrev = () => {
    setAutoplay(false)
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1))
  }

  const handleNext = () => {
    setAutoplay(false)
    setCurrentIndex((prevIndex) => (prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1))
  }

  const goToSlide = (index: number) => {
    setAutoplay(false)
    setCurrentIndex(index)
  }

  return (
    <div className="relative max-w-4xl mx-auto">
      <div className="overflow-hidden rounded-xl bg-gray-50 p-6 md:p-10 shadow-md">
        <div className="flex justify-center mb-6">
          {Array(testimonials[currentIndex].rating)
            .fill(0)
            .map((_, i) => (
              <Star key={i} className="h-6 w-6 fill-yellow-400 text-yellow-400" />
            ))}
        </div>

        <blockquote className="text-center">
          <p className="text-lg md:text-xl italic text-black mb-6">"{testimonials[currentIndex].text}"</p>
          <footer className="mt-4">
            <div className="font-bold text-lg text-[#1e40af]">{testimonials[currentIndex].name}</div>
            <div className="text-black/70">{testimonials[currentIndex].location}</div>
          </footer>
        </blockquote>
      </div>

      <div className="flex justify-center mt-6 space-x-2">
        {testimonials.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-3 w-3 rounded-full ${index === currentIndex ? "bg-[#1e40af]" : "bg-gray-300"}`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 md:-translate-x-6 bg-white shadow-md border-gray-200 hover:bg-gray-100 z-10"
        onClick={handlePrev}
        aria-label="Previous testimonial"
      >
        <ChevronLeft className="h-5 w-5" />
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 md:translate-x-6 bg-white shadow-md border-gray-200 hover:bg-gray-100 z-10"
        onClick={handleNext}
        aria-label="Next testimonial"
      >
        <ChevronRight className="h-5 w-5" />
      </Button>
    </div>
  )
}
